package com.raywenderlich.marsrovers.models


data class Photo(val id : Int, val img_src : String, val earth_date: String, val camera: Camera)