package com.raywenderlich.marsrovers.models


data class Camera(val id: Int, val name: String, val rover_id: Int, val full_name: String)